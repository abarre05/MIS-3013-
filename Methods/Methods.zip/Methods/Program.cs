﻿using System;

namespace Methods
{
    class Program
    {
        static void Main(string[] args);
        {
           Console.WriteLine("Please enter a type of animal");
        }

    static void Speak;
    {
        
        
    }
}

    
    
   
 


