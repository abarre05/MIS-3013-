﻿using System;

namespace Sumof3
{
    class Program
    {
        const double INT = "7.777";
        static void Main(string[] args)
        {
Console.WriteLine("Please enter three numbers >>");
            string NumInput = Console.ReadLine();
            double Num = Convert.ToDouble(NumInput);
            Console.WriteLine(Num.ToString);
        }
    }
}
