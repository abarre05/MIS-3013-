﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringManipulation
{
    class Program
    {
        static void Main(string[] args)

        {
            string sentence = "Programming today is a race between software engineers striving to build bigger and better idiot-proof programs, and the universe trying to build bigger and better idiots. So far, the universe is winning";
            Console.WriteLine("Programming today is a race between software engineers striving to build bigger and better idiot-proof programs, and the universe trying to build bigger and better idiots. So far, the universe is winning.");
           
            string word = "today";


            Console.WriteLine("Please pick a word to look for in the sentence above");
            Console.WriteLine("Please pick a work to change the word to");
            if (word == "today")
            {
            }
            else if (word != "today")
            {
            }
            else
                Environment.Exit();
        }

            }
        }
    
